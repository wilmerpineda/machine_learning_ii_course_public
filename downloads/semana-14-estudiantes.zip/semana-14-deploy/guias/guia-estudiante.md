# Semana 14 · Despliegue avanzado de un modelo de ML

## Reto y producto final

En equipos, llevarán un clasificador de abandono desde un notebook hasta una URL HTTPS pública. El producto incluye una aplicación Streamlit, una imagen Docker reproducible, una composición con Caddy, una VM de Compute Engine y evidencia de operación y limpieza.

La ruta de trabajo es:

`Colab → artefactos → Cloud Shell Editor → Docker → Compose → VM → HTTPS → prueba → limpieza`

Colab se usa para entrenar y exportar; **no** se usa como servidor. Su entorno es temporal y puede desaparecer sin aviso. Cloud Shell Editor reemplaza a VS Code en el aula: permite editar archivos y ejecutar comandos desde el navegador.

## Antes de la clase

Cada equipo debe contar con:

- una persona responsable de facturación y otra responsable técnica;
- una cuenta de Google que pueda crear un proyecto de Google Cloud;
- acceso a una cuenta de facturación válida;
- el paquete `semana-14-estudiantes.zip` descargado;
- el nombre corto del equipo, por ejemplo `equipo-03`.

No creen llaves JSON de cuentas de servicio. En esta práctica la identidad se adjunta directamente a la VM.

## Agenda: 240 minutos

### Sesión 1 · Del modelo a la imagen (120 min)

| Minutos | Actividad | Evidencia |
|---:|---|---|
| 0–15 | Arquitectura, costos y responsabilidades | Diagrama anotado |
| 15–40 | Proyecto, facturación, presupuesto y alertas | Capturas del proyecto y presupuesto |
| 40–55 | Cuenta de servicio sin llave | Nombre y correo de la cuenta |
| 55–80 | Colab: entrenamiento, contrato y artefactos | `model.joblib`, metadatos y predicción de referencia |
| 80–105 | Dockerfile guiado | Archivo completado y explicación por capas |
| 105–120 | Construcción y prueba en Cloud Shell | `docker build`, `docker run`, `/health` |

### Sesión 2 · De la imagen a HTTPS (120 min)

| Minutos | Actividad | Evidencia |
|---:|---|---|
| 0–20 | Compose por etapas | Configuración validada |
| 20–45 | VM, identidad y reglas de firewall | VM creada e IAP funcional |
| 45–65 | Docker Engine en Ubuntu | `docker run hello-world` |
| 65–90 | Despliegue con Caddy | Servicios saludables |
| 90–105 | Pruebas de aceptación y observabilidad | URL HTTPS y registro de pruebas |
| 105–115 | Defensa técnica del equipo | Explicación de una decisión |
| 115–120 | Limpieza y cierre | VM eliminada o detenida según instrucción |

## Reglas de seguridad y costo

1. Usen un proyecto exclusivo por equipo; no mezclen recursos personales.
2. Configuren el presupuesto antes de crear la VM. Una alerta **no bloquea ni limita** el gasto.
3. La cuenta de servicio `sa-streamlit-runtime` no requiere roles para este caso y nunca tendrá una llave descargada.
4. Abran al público solamente TCP 80 y 443. SSH entra por IAP desde `35.235.240.0/20`.
5. No publiquen el puerto 8501: solo Caddy puede llegar a Streamlit por la red interna de Compose.
6. Al finalizar, eliminen la VM y verifiquen que no queden discos, IP reservada ni reglas creadas por el equipo.

## Entrega

Entreguen un enlace a una carpeta con:

- URL HTTPS y captura donde se vea el candado;
- `Dockerfile`, `compose.yaml`, `Caddyfile` y `.dockerignore`;
- resultado de `docker compose ps` y fragmento pertinente de `docker compose logs`;
- evidencia de presupuesto y alertas;
- evidencia de la cuenta de servicio adjunta a la VM, sin llave;
- tabla de pruebas de aceptación;
- reflexión breve: qué garantiza Docker, qué garantiza Compose y qué queda fuera de ambos;
- evidencia de limpieza.

Consulte también [la guía de Google Cloud](guia-google-cloud.md), [la guía guiada de Compose](guia-compose.md) y [el laboratorio con la rúbrica](../../labs/semana-14.md).

## Fuentes oficiales

- [Preguntas frecuentes de Google Colab](https://research.google.com/colaboratory/faq.html)
- [Editor de Cloud Shell](https://docs.cloud.google.com/shell/docs/editor-overview)
- [Introducción a Dockerfile](https://docs.docker.com/build/concepts/dockerfile/)
- [Docker Compose](https://docs.docker.com/compose/gettingstarted/)

