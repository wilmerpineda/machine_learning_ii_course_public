"""Adaptadores de bibliotecas externas al contrato del curso."""

from __future__ import annotations

from dataclasses import asdict

import numpy as np
from sklearn.manifold import TSNE

from manifold_lab.base import BaseEmbeddingReducer, FloatArray, validated_matrix
from manifold_lab.config import TSNEConfig, UMAPConfig


class SklearnTSNEAdapter(BaseEmbeddingReducer):
    """Expone scikit-learn t-SNE mediante la interfaz comun."""

    def __init__(self, config: TSNEConfig | None = None) -> None:
        super().__init__()
        self.config = config or TSNEConfig()

    @property
    def name(self) -> str:
        """Nombre del adaptador."""
        return "t-SNE"

    def get_params(self) -> dict[str, object]:
        """Devuelve parametros serializables."""
        return asdict(self.config)

    def fit_transform(self, values: FloatArray) -> FloatArray:
        """Ajusta la implementacion Barnes-Hut de scikit-learn."""
        matrix = validated_matrix(values)
        self.config.validate(len(matrix))
        model = TSNE(
            n_components=2,
            perplexity=self.config.perplexity,
            learning_rate=self.config.learning_rate,
            early_exaggeration=self.config.early_exaggeration,
            max_iter=self.config.n_iter,
            init="pca",
            random_state=self.config.random_state,
        )
        self._embedding = np.asarray(model.fit_transform(matrix), dtype=np.float64)
        return self.embedding_


class UmapLearnAdapter(BaseEmbeddingReducer):
    """Expone umap-learn mediante la interfaz comun."""

    def __init__(self, config: UMAPConfig | None = None) -> None:
        super().__init__()
        self.config = config or UMAPConfig()

    @property
    def name(self) -> str:
        """Nombre del adaptador."""
        return "UMAP"

    def get_params(self) -> dict[str, object]:
        """Devuelve parametros serializables."""
        return asdict(self.config)

    def fit_transform(self, values: FloatArray) -> FloatArray:
        """Ajusta UMAP con una semilla reproducible."""
        import umap

        matrix = validated_matrix(values)
        self.config.validate(len(matrix))
        model = umap.UMAP(
            n_components=2,
            n_neighbors=self.config.n_neighbors,
            min_dist=self.config.min_dist,
            learning_rate=self.config.learning_rate,
            n_epochs=self.config.n_epochs,
            random_state=self.config.random_state,
        )
        self._embedding = np.asarray(model.fit_transform(matrix), dtype=np.float64)
        return self.embedding_
