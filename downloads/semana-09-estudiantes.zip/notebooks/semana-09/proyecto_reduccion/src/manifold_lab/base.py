"""Contrato comun de los reductores de dimensionalidad."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Mapping
from typing import TypeAlias

import numpy as np
from numpy.typing import NDArray

FloatArray: TypeAlias = NDArray[np.float64]


def validated_matrix(values: FloatArray) -> FloatArray:
    """Devuelve una matriz finita de punto flotante con al menos tres filas."""
    matrix = np.asarray(values, dtype=np.float64)
    if matrix.ndim != 2:
        raise ValueError("X debe ser una matriz bidimensional.")
    if matrix.shape[0] < 3 or matrix.shape[1] < 2:
        raise ValueError("X necesita al menos tres filas y dos columnas.")
    if not np.isfinite(matrix).all():
        raise ValueError("X contiene valores no finitos.")
    return matrix


class BaseEmbeddingReducer(ABC):
    """Interfaz minima para reductores que producen coordenadas bidimensionales."""

    def __init__(self) -> None:
        self._embedding: FloatArray | None = None

    @property
    def embedding_(self) -> FloatArray:
        """Coordenadas ajustadas; falla si el modelo aun no se ha ejecutado."""
        if self._embedding is None:
            raise RuntimeError("Ejecute fit_transform antes de consultar embedding_.")
        return self._embedding.copy()

    @property
    @abstractmethod
    def name(self) -> str:
        """Nombre corto para tablas y figuras."""

    @abstractmethod
    def fit_transform(self, values: FloatArray) -> FloatArray:
        """Ajusta el reductor y devuelve dos coordenadas por observacion."""

    @abstractmethod
    def get_params(self) -> Mapping[str, object]:
        """Devuelve parametros serializables del experimento."""
