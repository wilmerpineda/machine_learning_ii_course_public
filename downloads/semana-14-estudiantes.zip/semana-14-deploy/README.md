# Proyecto de despliegue · Semana 14

Esta carpeta contiene una aplicación Streamlit de churn, su artefacto de modelo,
pruebas, Dockerfile, Docker Compose y Caddy.

## Contrato

- Streamlit escucha únicamente dentro de Docker en `8501`.
- Caddy publica `80` y `443` y enruta a `app:8501`.
- `.env` define `APP_DOMAIN` y nunca se copia a la imagen.
- `artifacts/model_metadata.json` define el orden de variables, umbral y versión.
- No se usan llaves JSON de cuentas de servicio.

## Desarrollo

```bash
python train_model.py
pytest -q
docker build -t ml2-churn:1.0 .
docker compose config
```

El ZIP estudiantil reemplaza `Dockerfile` y `compose.yaml` por las plantillas con
`TODO`. El paquete docente conserva las soluciones ejecutables.
