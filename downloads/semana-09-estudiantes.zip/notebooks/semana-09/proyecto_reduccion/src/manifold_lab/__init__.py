"""Herramientas orientadas a objetos para auditar embeddings no lineales."""

from manifold_lab.adapters import SklearnTSNEAdapter, UmapLearnAdapter
from manifold_lab.base import BaseEmbeddingReducer
from manifold_lab.config import TSNEConfig, UMAPConfig
from manifold_lab.data import HARDataset, HARDatasetLoader
from manifold_lab.evaluation import EmbeddingEvaluator
from manifold_lab.experiment import ExperimentRunner
from manifold_lab.results import EmbeddingMetrics, EmbeddingResult
from manifold_lab.tsne import TSNEFromScratch
from manifold_lab.umap_model import UMAPFromScratch

__all__ = [
    "BaseEmbeddingReducer",
    "EmbeddingEvaluator",
    "EmbeddingMetrics",
    "EmbeddingResult",
    "ExperimentRunner",
    "HARDataset",
    "HARDatasetLoader",
    "SklearnTSNEAdapter",
    "TSNEConfig",
    "TSNEFromScratch",
    "UMAPConfig",
    "UMAPFromScratch",
    "UmapLearnAdapter",
]
