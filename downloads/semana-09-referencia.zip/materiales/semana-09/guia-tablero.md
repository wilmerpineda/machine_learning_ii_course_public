# Guía de tablero · t-SNE y UMAP

Mantenga tres zonas visibles: **espacio original**, **objeto preservado** y
**espacio 2D**. No borre la columna central hasta el cierre comparativo.

## Día 1 · t-SNE

### Tablero 1 · Una fila de afinidades (18 minutos)

1. Dibuje cuatro puntos con distancias desde (x_i): 0,5; 1; 2 y 4.
2. Escriba
   (p_{j|i}\propto\exp(-\beta_i d_{ij}^2)).
3. Calcule pesos con beta igual a uno y normalice.
4. Calcule (H(P_i)) y ​​`exp(H)`.
5. Pregunte si beta debe subir o bajar para reducir la perplejidad.
6. Encierre la idea: **una escala por punto**.

### Tablero 2 · Dos distribuciones (15 minutos)

1. Escriba la simetrización (p_{ij}=(p_{j|i}+p_{i|j})/(2n)).
2. Dibuje gaussiana en alta dimensión y Student-t en el plano.
3. Escriba (KL(P\Vert Q)), destacando su asimetría.
4. Use dos pares: vecino perdido y vecino inventado.

### Tablero 3 · Gradiente y contrato (12 minutos)

1. Separe el gradiente en signo, dirección y peso de cola.
2. Dibuje `BaseEmbeddingReducer ← TSNEFromScratch`.
3. A la derecha ubique `EmbeddingResult → EmbeddingEvaluator`.
4. Marque que el notebook solo conoce la interfaz.

## Día 2 · UMAP

### Tablero 1 · Grafo local (20 minutos)

1. Dibuje seis puntos: tres densos, dos medianos y uno aislado.
2. Trace tres vecinos por punto con flechas dirigidas.
3. Marque rho como la primera distancia positiva.
4. Explique sigma como escala ajustada por búsqueda binaria.
5. Calcule dos pesos (w_{i\to j}) en direcciones opuestas.

### Tablero 2 · Unión y espacio 2D (15 minutos)

1. Escriba (w_{ij}=a+b-ab).
2. Verifique que 0 y 1 permanecen en el intervalo.
3. Dibuje el mismo grafo en el plano con aristas fuertes y débiles.
4. Escriba (v_{ij}=[1+a d^{2b}]^{-1}).

### Tablero 3 · Comparación final (15 minutos)

Construya esta tabla con aportes del grupo:

| Método | Objeto preservado | Parámetro de escala | Riesgo principal |
|---|---|---|---|
| PCA | Varianza lineal | Componentes | Perder curvatura |
| t-SNE | Afinidades probabilísticas | Perplejidad | Leer distancias globales |
| UMAP | Grafo difuso local | Vecinos | Leer topología como garantía |

Termine con tres pruebas: vecinos retenidos, estabilidad y explicación rival.

