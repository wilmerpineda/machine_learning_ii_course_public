# Google Cloud paso a paso: proyecto, costo, identidad y VM

> La interfaz de Google Cloud cambia con frecuencia. Busquen cada producto por su nombre en la barra superior y verifiquen el proyecto activo antes de confirmar una acción.

## 1. Crear el proyecto del equipo

1. Abra [Google Cloud Console](https://console.cloud.google.com/).
2. En el selector de proyectos, elija **New project / Proyecto nuevo**.
3. Nombre: `ml2-semana14-equipo-XX`.
4. Copie el **Project ID** en la bitácora; puede diferir del nombre.
5. Confirme que el selector superior muestra el proyecto nuevo.

En Cloud Shell:

```bash
gcloud config set project PROJECT_ID
gcloud config get-value project
```

## 2. Vincular facturación y habilitar APIs

En **Billing / Facturación**, vincule el proyecto a la cuenta autorizada. Luego habilite:

```bash
gcloud services enable compute.googleapis.com iam.googleapis.com iap.googleapis.com
```

Una VM genera cobros mientras existe y puede dejar costos por disco o IP. El nivel gratuito de Compute Engine aplica solo bajo condiciones y regiones específicas; esta práctica **no presume** que sea gratis.

## 3. Crear presupuesto y alertas antes de consumir

1. Abra **Billing → Budgets & alerts**.
2. Cree un presupuesto llamado `ml2-semana14-equipo-XX`.
3. Alcance: solamente el proyecto del equipo.
4. Importe: USD 5 o su equivalente autorizado por el docente.
5. Umbrales: 50 %, 90 % y 100 % del gasto real.
6. Active notificaciones por correo para administradores y usuarios de facturación.
7. Guarde una captura sin datos sensibles.

**Advertencia:** los presupuestos envían alertas; no ponen un límite automático ni apagan recursos. La limpieza sigue siendo responsabilidad del equipo.

## 4. Crear una cuenta de servicio sin llave

1. Abra **IAM & Admin → Service Accounts**.
2. Cree `sa-streamlit-runtime` con descripción `Identidad de ejecución de la VM de Semana 14`.
3. No otorgue roles: la aplicación solo lee archivos incluidos en su imagen.
4. Finalice sin crear ni descargar llaves.
5. Copie su correo, con forma `sa-streamlit-runtime@PROJECT_ID.iam.gserviceaccount.com`.

Principio aplicado: una carga usa una identidad adjunta y privilegios mínimos; no un secreto JSON copiado al servidor.

## 5. Crear las reglas de firewall

En **VPC network → Firewall**, cree reglas restringidas al tag `streamlit-web`:

| Regla | Origen | Protocolos/puertos | Tag de destino |
|---|---|---|---|
| `allow-streamlit-web` | `0.0.0.0/0` | TCP 80, 443 | `streamlit-web` |
| `allow-ssh-from-iap` | `35.235.240.0/20` | TCP 22 | `streamlit-web` |

La primera regla es pública porque la aplicación debe ser accesible. La segunda limita SSH al rango usado por IAP. No creen una regla pública para 8501.

Si existe `default-allow-ssh`, no dependan de ella. Solo después de comprobar el acceso mediante IAP, el responsable del proyecto puede deshabilitarla o eliminarla dentro de este proyecto de práctica.

## 6. Crear la VM

En **Compute Engine → VM instances → Create instance**:

| Campo | Valor de la práctica |
|---|---|
| Nombre | `vm-streamlit-equipo-XX` |
| Región/zona | `us-central1` / una zona disponible |
| Tipo | `e2-small` |
| Imagen | Ubuntu 24.04 LTS |
| Disco | 20 GB, Standard persistent disk |
| Network tag | `streamlit-web` |
| Service account | `sa-streamlit-runtime@…` |
| Access scopes | Allow default access |
| External IP | Ephemeral |

No marque “Allow HTTP/HTTPS” si ya creó las reglas explícitas. Después de crearla, anote la IP externa.

Conéctese desde el botón **SSH** del navegador. Si usan CLI:

```bash
gcloud compute ssh vm-streamlit-equipo-XX --zone=ZONE --tunnel-through-iap
```

## 7. Instalar Docker Engine en Ubuntu

Dentro de la VM ejecute los comandos oficiales del repositorio apt de Docker:

```bash
sudo apt update
sudo apt install -y ca-certificates curl
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc
sudo tee /etc/apt/sources.list.d/docker.sources >/dev/null <<EOF
Types: deb
URIs: https://download.docker.com/linux/ubuntu
Suites: $(. /etc/os-release && echo "${UBUNTU_CODENAME:-$VERSION_CODENAME}")
Components: stable
Architectures: $(dpkg --print-architecture)
Signed-By: /etc/apt/keyrings/docker.asc
EOF
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
sudo usermod -aG docker "$USER"
exit
```

Reconéctese y valide:

```bash
docker run --rm hello-world
docker compose version
```

## 8. Subir el proyecto y definir el dominio

La opción sencilla es subir `semana-14-deploy.zip` desde el menú de SSH o Cloud Shell y descomprimirlo:

```bash
sudo apt install -y unzip
unzip semana-14-deploy.zip
cd semana-14-deploy
```

Obtenga la IP desde la consola. Si fuera `34.120.10.20`, use:

```bash
cp .env.example .env
sed -i 's/^APP_DOMAIN=.*/APP_DOMAIN=34-120-10-20.sslip.io/' .env
```

`sslip.io` resuelve un nombre que contiene una IP. Si no responde en la red del aula, use el equivalente `34-120-10-20.nip.io` y cambie `.env`.

## 9. Desplegar y comprobar

```bash
docker compose config
docker compose up -d --build
docker compose ps
docker compose logs --tail=100 app caddy
```

Abra `https://34-120-10-20.sslip.io`, reemplace los valores, pulse **Estimar riesgo** y confirme que aparecen probabilidad, decisión y explicación.

Pruebas desde la VM:

```bash
curl -I http://34-120-10-20.sslip.io
curl -I https://34-120-10-20.sslip.io
docker compose ps
```

El primer comando debería redirigir a HTTPS; el segundo debería responder sin `-k`.

## 10. Limpieza obligatoria

1. Recoja la evidencia antes de borrar.
2. En Compute Engine, elimine `vm-streamlit-equipo-XX` y su disco de arranque.
3. Verifique que no quede una IP externa reservada.
4. Elimine `allow-streamlit-web` y `allow-ssh-from-iap` si el proyecto no se reutilizará.
5. Revise **Billing → Reports** y **Compute Engine → Disks**.
6. Si el proyecto fue creado solo para esta clase, ciérrelo desde **IAM & Admin → Settings → Shut down** después de la revisión docente.

Eliminar el proyecto es destructivo y queda programado para borrado. Háganlo únicamente en el proyecto exclusivo del equipo.

## Fuentes oficiales

- [Presupuestos y alertas](https://docs.cloud.google.com/billing/docs/how-to/budgets)
- [Crear cuentas de servicio](https://docs.cloud.google.com/iam/docs/service-accounts-create)
- [Cuentas de servicio en Compute Engine](https://docs.cloud.google.com/compute/docs/access/service-accounts)
- [SSH en el navegador](https://docs.cloud.google.com/compute/docs/connect/ssh-in-browser)
- [IAP TCP forwarding](https://docs.cloud.google.com/iap/docs/using-tcp-forwarding)
- [Instalar Docker Engine en Ubuntu](https://docs.docker.com/engine/install/ubuntu/)

