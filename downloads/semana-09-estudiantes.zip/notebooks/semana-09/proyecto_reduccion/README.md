# Manifold Lab

Paquete didactico de la semana 9 de Machine Learning II. Separa carga de datos,
reduccion, evaluacion, visualizacion y orquestacion para evitar logica de negocio
en los notebooks.

## Instalacion

```powershell
python -m pip install -e .
```

## Puerta de calidad

```powershell
python -m flake8 src tests
python -m mypy --strict src
python -m pylint --fail-under=9.5 src tests
python -m pytest --cov=manifold_lab --cov-fail-under=85
```

Las implementaciones `FromScratch` son exactas y deliberadamente pequenas. No
son sustitutos de las bibliotecas optimizadas para datos de produccion.

