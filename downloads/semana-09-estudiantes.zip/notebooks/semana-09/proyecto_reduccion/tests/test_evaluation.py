"""Pruebas de resultados y evaluacion."""

from __future__ import annotations

import numpy as np
import pytest
from sklearn.decomposition import PCA

from manifold_lab import EmbeddingEvaluator, EmbeddingResult


def test_evaluator_returns_bounded_local_metrics() -> None:
    """Las medidas locales pertenecen al intervalo unitario."""
    random = np.random.default_rng(42)
    values = random.normal(size=(80, 6))
    coordinates = PCA(n_components=2).fit_transform(values)
    result = EmbeddingResult("PCA", coordinates, {}, 0.1)
    metrics = EmbeddingEvaluator(n_neighbors=5).evaluate(values, result)
    assert 0 <= metrics.trustworthiness <= 1
    assert 0 <= metrics.neighbor_overlap <= 1
    assert -1 <= metrics.distance_correlation <= 1


def test_result_rejects_wrong_shape() -> None:
    """Un resultado debe contener exactamente dos coordenadas."""
    with pytest.raises(ValueError):
        EmbeddingResult("malo", np.ones((10, 3)), {}, 0.0)
