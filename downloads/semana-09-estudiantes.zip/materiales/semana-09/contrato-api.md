# Contrato de implementación · `manifold_lab`

## Regla de dependencia

El notebook depende de abstracciones y objetos resultado. Los algoritmos no
dependen del notebook, de pandas ni de matplotlib.

```text
HARDatasetLoader ──→ ndarray
                         ↓
BaseEmbeddingReducer ← TSNEFromScratch / UMAPFromScratch / adapters
                         ↓
                 EmbeddingResult
                    ↙         ↘
       EmbeddingEvaluator   EmbeddingPlotter
                    ↘         ↙
                  ExperimentRunner
```

## Interfaz pública

### `BaseEmbeddingReducer`

- `name`: identificador legible.
- `fit_transform(X)`: ajusta y devuelve `(n, 2)`.
- `get_params()`: parámetros serializables.
- `embedding_`: copia del resultado; falla antes del ajuste.

### Objetos de dominio

- `TSNEConfig` y `UMAPConfig`: dataclasses inmutables con validación.
- `EmbeddingResult`: coordenadas, parámetros, duración e historial.
- `EmbeddingMetrics`: preservación local, distancia y costo.

### Servicios

- `HARDatasetLoader`: valida el paquete offline.
- `EmbeddingEvaluator`: calcula métricas sin ajustar modelos.
- `ExperimentRunner`: ejecuta reductores intercambiables.
- `EmbeddingPlotter`: visualiza resultados ya calculados.

## Extensión esperada

Para agregar Isomap, implemente `IsomapAdapter(BaseEmbeddingReducer)`. No cambie
`ExperimentRunner`, `EmbeddingEvaluator` ni las celdas que consumen la interfaz.

## Puerta de calidad

```powershell
python -m flake8 src tests
python -m mypy --strict src
python -m pylint --fail-under=9.5 src tests
python -m pytest --cov=manifold_lab --cov-fail-under=85
```

