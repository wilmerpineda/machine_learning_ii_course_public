# Laboratorio formativo · Atlas del movimiento humano

**Semana 9 · Equipos de 3 o 4 · Sin nueva nota.**

## Pregunta

¿La estructura de las 561 características refleja principalmente actividad,
participante o una combinación de ambas? Construya una respuesta que sobreviva
a cambios razonables de método y parámetros.

## Contrato experimental

1. Use las mismas 1.800 filas y el mismo PCA50 para las comparaciones principales.
2. No use actividad ni participante durante el ajuste.
3. Compare PCA, t-SNE y UMAP con semilla registrada.
4. Varíe un parámetro por vez y repita al menos una semilla.
5. Reporte `trustworthiness`, solapamiento de vecinos y tiempo.

## Entrega

- Notebook ejecutado.
- Paquete `manifold_lab` con puerta de calidad superada.
- Tres figuras interpretadas y una tabla de sensibilidad.
- Recomendación de cinco a ocho líneas:

> Observo → cuantifico → interpreto → comprobaría → no puedo concluir.

## Rúbrica de retroalimentación

| Criterio | Consolidado | En desarrollo | Requiere revisión |
|---|---|---|---|
| Matemáticas | Distingue afinidades, grafo y pérdidas | Describe pasos con vacíos | Trata ambos métodos como cajas negras |
| Auditoría | Usa vecinos, estabilidad y explicación rival | Usa una sola métrica | Elige por apariencia |
| Arquitectura | Responsabilidades separadas y contrato extensible | Algunas dependencias cruzadas | Lógica central en el notebook |
| Calidad | flake8, mypy, pylint y pytest superados | Advertencias justificables | No hay validación automática |
| Comunicación | Conclusión trazable y limitada | Evidencia poco conectada | Afirma grupos verdaderos |

