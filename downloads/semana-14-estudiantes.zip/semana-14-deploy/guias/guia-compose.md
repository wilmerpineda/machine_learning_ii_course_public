# Construcción guiada de Docker Compose

## La idea esencial

Un `Dockerfile` responde **cómo construir una imagen**. `compose.yaml` responde **qué servicios deben ejecutarse juntos y cómo se conectan**. En este proyecto hay dos servicios:

- `app`: ejecuta Streamlit en el puerto interno 8501;
- `caddy`: recibe tráfico público en 80/443, obtiene HTTPS y reenvía a `app:8501`.

No intenten escribir todo el archivo de memoria. En cada etapa sigan este ciclo:

1. **Observar:** leer el fragmento y ubicar claves, valores y sangría.
2. **Predecir:** decir qué creen que hará antes de ejecutarlo.
3. **Completar:** sustituir solamente los `TODO` de esa etapa.
4. **Validar:** ejecutar `docker compose config`.
5. **Ejecutar:** levantar los servicios involucrados.
6. **Inspeccionar:** revisar estado, salud y logs.
7. **Explicar:** justificar una decisión con sus palabras.
8. **Integrar:** conservar la etapa que funciona y añadir la siguiente.

Copien `plantillas/compose.yaml` como `compose.yaml`. No editen la plantilla original.

## Etapa 0 · Variables y sintaxis

Creen `.env` a partir de `.env.example` y dejen temporalmente:

```dotenv
APP_DOMAIN=localhost
```

Ejecuten:

```bash
docker compose config
```

Si aparece un error, revisen primero espacios, guiones y dos puntos. YAML depende de la sangría.

## Etapa 1 · Servicio `app`

Completen:

- contexto de construcción: el directorio actual;
- nombre y versión de la imagen;
- política para reiniciar salvo detención explícita;
- puerto interno de Streamlit.

Pistas: el navegador todavía no puede entrar; `expose` documenta el puerto para la red interna, mientras `ports` publicaría un puerto en la máquina anfitriona.

Comprueben:

```bash
docker compose config
docker compose build app
docker compose run --rm --no-deps app python -c "from pathlib import Path; assert Path('/app/artifacts/model.joblib').exists()"
```

Explique: ¿por qué no usamos `ports: - "8501:8501"` en el despliegue final?

## Etapa 2 · Salud y dependencia real

El `healthcheck` llama a `/_stcore/health` desde el propio contenedor. Completen el intervalo y ejecuten:

```bash
docker compose up -d app
docker compose ps
docker inspect --format='{{json .State.Health}}' ml2-churn-app-1
```

El nombre exacto del contenedor puede variar; obténganlo con `docker compose ps -q app` si es necesario.

Explique: `running` indica que el proceso vive; `healthy` indica que responde a la prueba definida.

## Etapa 3 · Proxy Caddy

Completen la imagen oficial de Caddy, la condición de dependencia saludable, la variable `APP_DOMAIN` y los puertos públicos. Lean `Caddyfile`:

```caddyfile
{$APP_DOMAIN} {
    reverse_proxy app:8501
}
```

`app` funciona como nombre DNS dentro de la red de Compose. Caddy es el único servicio expuesto al exterior.

En Cloud Shell, con `APP_DOMAIN=localhost`, validen la configuración. La prueba HTTPS real se hace en la VM con un dominio `sslip.io` derivado de la IP pública.

## Etapa 4 · Volúmenes persistentes

Caddy guarda certificados y estado en `/data` y `/config`. Completen los volúmenes nombrados y ejecuten:

```bash
docker compose config
docker compose up -d --build
docker compose ps
docker compose logs --tail=80 app caddy
```

Explique: si se recrea el contenedor Caddy, ¿por qué no queremos perder `/data`?

## Diagnóstico rápido

| Síntoma | Inspección | Corrección probable |
|---|---|---|
| YAML inválido | `docker compose config` | Corregir sangría o `TODO` restante |
| `app` no está saludable | `docker compose logs app` | Revisar artefactos, dependencias y puerto |
| Caddy no inicia | `docker compose logs caddy` | Revisar dominio, 80/443 y `Caddyfile` |
| URL responde por HTTP pero no HTTPS | DNS `sslip.io`, hora y firewall | Esperar emisión, revisar 443 y logs |
| Cambios no aparecen | `docker compose build --no-cache app` | Reconstruir y recrear |

## Criterio de terminación

El archivo está listo cuando:

- `docker compose config` termina sin errores ni `TODO`;
- `app` aparece `healthy`;
- solo Caddy publica puertos del host;
- la URL HTTPS carga y produce una predicción;
- pueden explicar `build`, `image`, `expose`, `ports`, `healthcheck`, `depends_on` y `volumes`.

Fuentes: [Compose Quickstart](https://docs.docker.com/compose/gettingstarted/) y [Automatic HTTPS de Caddy](https://caddyserver.com/docs/automatic-https).

