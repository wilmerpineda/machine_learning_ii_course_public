"""Metricas para separar preservacion local de apariencia visual."""

from __future__ import annotations

from typing import cast

import numpy as np
from scipy.spatial.distance import pdist
from scipy.stats import spearmanr
from sklearn.manifold import trustworthiness
from sklearn.neighbors import NearestNeighbors

from manifold_lab.base import FloatArray, validated_matrix
from manifold_lab.results import EmbeddingMetrics, EmbeddingResult


def _neighbor_overlap(
    original: FloatArray, embedded: FloatArray, k_value: int
) -> float:
    """Promedia la fraccion de vecinos originales retenidos en el mapa."""
    high = NearestNeighbors(n_neighbors=k_value + 1).fit(original)
    low = NearestNeighbors(n_neighbors=k_value + 1).fit(embedded)
    high_indices = high.kneighbors(return_distance=False)[:, 1:]
    low_indices = low.kneighbors(return_distance=False)[:, 1:]
    overlaps = [
        len(set(high_row).intersection(low_row)) / k_value
        for high_row, low_row in zip(high_indices, low_indices, strict=True)
    ]
    return float(np.mean(overlaps))


class EmbeddingEvaluator:
    """Evalua estructura local, global y costo de un resultado."""

    def __init__(self, n_neighbors: int = 10, max_pairs: int = 50_000) -> None:
        if n_neighbors < 2 or max_pairs < 100:
            raise ValueError("La configuracion de evaluacion es invalida.")
        self.n_neighbors = n_neighbors
        self.max_pairs = max_pairs

    def evaluate(
        self, original: FloatArray, result: EmbeddingResult
    ) -> EmbeddingMetrics:
        """Calcula diagnosticos comparables para un embedding."""
        matrix = validated_matrix(original)
        embedded = validated_matrix(result.coordinates)
        if len(matrix) != len(embedded):
            raise ValueError("Original y embedding deben tener las mismas filas.")
        if self.n_neighbors >= len(matrix) / 2:
            raise ValueError("n_neighbors debe ser menor que n_samples / 2.")
        high_distances = pdist(matrix)
        low_distances = pdist(embedded)
        if len(high_distances) > self.max_pairs:
            random = np.random.default_rng(42)
            indices = random.choice(len(high_distances), self.max_pairs, replace=False)
            high_distances = high_distances[indices]
            low_distances = low_distances[indices]
        correlation = cast(float, spearmanr(high_distances, low_distances).statistic)
        return EmbeddingMetrics(
            trustworthiness=float(
                trustworthiness(
                    matrix, embedded, n_neighbors=self.n_neighbors, metric="euclidean"
                )
            ),
            neighbor_overlap=_neighbor_overlap(matrix, embedded, self.n_neighbors),
            distance_correlation=correlation,
            duration_seconds=result.duration_seconds,
        )
