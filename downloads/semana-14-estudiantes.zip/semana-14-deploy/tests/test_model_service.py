"""Regression tests for the serialized model contract."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest


PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "app"))

from model_service import load_bundle, make_frame, predict  # noqa: E402


@pytest.fixture(scope="module")
def bundle():
    return load_bundle(PROJECT / "artifacts")


def test_feature_contract_matches_model(bundle) -> None:
    model, metadata = bundle
    assert list(model.feature_names_in_) == metadata["feature_order"]


def test_reference_prediction_is_stable(bundle) -> None:
    model, metadata = bundle
    reference = json.loads(
        (PROJECT / "artifacts" / "reference_prediction.json").read_text(
            encoding="utf-8"
        )
    )
    result = predict(model, metadata, reference["input"])
    assert result["probability"] == pytest.approx(
        reference["probability"], abs=reference["tolerance"]
    )
    assert result["prediction"] == reference["prediction"]


def test_missing_feature_is_rejected(bundle) -> None:
    _, metadata = bundle
    with pytest.raises(ValueError, match="Faltan variables"):
        make_frame({}, metadata["feature_order"])
