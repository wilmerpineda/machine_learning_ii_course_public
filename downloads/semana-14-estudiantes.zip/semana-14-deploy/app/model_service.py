"""Runtime services for loading, predicting and explaining the model."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd


def load_bundle(artifact_dir: str | Path) -> tuple[Any, dict[str, Any]]:
    """Load the model and its explicit runtime contract."""
    path = Path(artifact_dir)
    model = joblib.load(path / "model.joblib")
    metadata = json.loads((path / "model_metadata.json").read_text(encoding="utf-8"))
    missing = set(metadata["feature_order"]) - set(model.feature_names_in_)
    if missing:
        raise ValueError(f"El contrato contiene variables desconocidas: {sorted(missing)}")
    return model, metadata


def make_frame(values: dict[str, float], feature_order: list[str]) -> pd.DataFrame:
    """Build one ordered row and reject missing or non-finite inputs."""
    missing = [feature for feature in feature_order if feature not in values]
    if missing:
        raise ValueError(f"Faltan variables: {missing}")
    frame = pd.DataFrame([[values[name] for name in feature_order]], columns=feature_order)
    if not np.isfinite(frame.to_numpy(dtype=float)).all():
        raise ValueError("Todas las entradas deben ser números finitos")
    return frame


def predict(
    model: Any,
    metadata: dict[str, Any],
    values: dict[str, float],
) -> dict[str, float | int]:
    """Return probability and thresholded prediction."""
    frame = make_frame(values, metadata["feature_order"])
    probability = float(model.predict_proba(frame)[0, 1])
    threshold = float(metadata["decision_threshold"])
    return {
        "probability": probability,
        "threshold": threshold,
        "prediction": int(probability >= threshold),
    }


def local_shap_values(
    model: Any,
    metadata: dict[str, Any],
    values: dict[str, float],
) -> pd.DataFrame:
    """Return robust binary-class TreeSHAP contributions for one observation."""
    import shap

    frame = make_frame(values, metadata["feature_order"])
    explanation = shap.TreeExplainer(model)(frame)
    raw = np.asarray(explanation.values)
    if raw.ndim == 3:
        class_index = min(1, raw.shape[2] - 1)
        contributions = raw[0, :, class_index]
    elif raw.ndim == 2:
        contributions = raw[0]
    else:
        raise ValueError(f"Forma SHAP no reconocida: {raw.shape}")
    result = pd.DataFrame(
        {
            "variable": metadata["feature_order"],
            "aporte_shap": contributions.astype(float),
        }
    )
    result["magnitud"] = result["aporte_shap"].abs()
    return result.sort_values("magnitud", ascending=False).drop(columns="magnitud")
