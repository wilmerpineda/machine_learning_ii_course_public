"""Nucleo denso de UMAP para inspeccionar el grafo y su optimizacion."""

from __future__ import annotations

from dataclasses import asdict
from typing import cast

import numpy as np
from scipy.optimize import curve_fit
from scipy.spatial.distance import pdist, squareform
from sklearn.decomposition import PCA

from manifold_lab.base import BaseEmbeddingReducer, FloatArray, validated_matrix
from manifold_lab.config import UMAPConfig


def _smooth_knn_dist(neighbor_distances: FloatArray) -> tuple[FloatArray, FloatArray]:
    """Calcula radios locales y escalas que aproximan log2(k) vecinos."""
    n_samples, n_neighbors = neighbor_distances.shape
    rho = neighbor_distances[:, 0].copy()
    sigma = np.ones(n_samples, dtype=np.float64)
    target = np.log2(n_neighbors)
    for row in range(n_samples):
        lower, upper, midpoint = 0.0, np.inf, 1.0
        shifted = np.maximum(0.0, neighbor_distances[row] - rho[row])
        for _ in range(64):
            total = float(np.exp(-shifted / midpoint).sum())
            if abs(total - target) < 1e-6:
                break
            if total > target:
                upper = midpoint
                midpoint = (lower + upper) / 2
            else:
                lower = midpoint
                midpoint = midpoint * 2 if np.isinf(upper) else (lower + upper) / 2
        sigma[row] = max(midpoint, np.spacing(1.0))
    return rho, sigma


def fuzzy_neighbor_graph(values: FloatArray, n_neighbors: int) -> FloatArray:
    """Construye la union difusa del grafo dirigido de vecinos."""
    matrix = validated_matrix(values)
    if not 2 <= n_neighbors < len(matrix):
        raise ValueError("n_neighbors esta fuera del rango permitido.")
    distances = cast(FloatArray, squareform(pdist(matrix)))
    order = np.argsort(distances, axis=1)[:, 1 : n_neighbors + 1]
    local_distances = np.take_along_axis(distances, order, axis=1)
    rho, sigma = _smooth_knn_dist(local_distances)
    directed = np.zeros_like(distances)
    for row in range(len(matrix)):
        weights = np.exp(
            -np.maximum(0.0, local_distances[row] - rho[row]) / sigma[row]
        )
        directed[row, order[row]] = weights
    graph = directed + directed.T - directed * directed.T
    np.fill_diagonal(graph, 0.0)
    return graph


def _find_curve(spread: float, min_dist: float) -> tuple[float, float]:
    """Ajusta la curva de pertenencia suave usada por UMAP."""
    distances = np.linspace(0, spread * 3, 300)
    target = np.where(
        distances < min_dist,
        1.0,
        np.exp(-(distances - min_dist) / spread),
    )

    def curve(value: FloatArray, a_value: float, b_value: float) -> FloatArray:
        return 1.0 / (1.0 + a_value * value ** (2 * b_value))

    parameters, _ = curve_fit(curve, distances, target, p0=(1.5, 0.9))
    return float(parameters[0]), float(parameters[1])


class UMAPFromScratch(BaseEmbeddingReducer):
    """UMAP denso con todos los pares, pensado para grupos pequenos."""

    def __init__(self, config: UMAPConfig | None = None) -> None:
        super().__init__()
        self.config = config or UMAPConfig()
        self.graph_: FloatArray | None = None
        self.history_: list[float] = []

    @property
    def name(self) -> str:
        """Nombre del reductor."""
        return "UMAP desde cero"

    def get_params(self) -> dict[str, object]:
        """Devuelve una copia de la configuracion."""
        return asdict(self.config)

    def fit_transform(self, values: FloatArray) -> FloatArray:
        """Minimiza entropia cruzada entre grafos difusos densos."""
        matrix = validated_matrix(values)
        n_samples = matrix.shape[0]
        self.config.validate(n_samples)
        if n_samples > 300:
            raise ValueError("La version densa admite como maximo 300 filas.")
        graph = fuzzy_neighbor_graph(matrix, self.config.n_neighbors)
        embedding = PCA(
            n_components=2, random_state=self.config.random_state
        ).fit_transform(matrix)
        embedding /= max(float(np.std(embedding)), np.spacing(1.0))
        a_value, b_value = _find_curve(self.config.spread, self.config.min_dist)
        self.history_ = []
        mask = ~np.eye(n_samples, dtype=bool)
        for epoch in range(self.config.n_epochs):
            squared = cast(
                FloatArray, squareform(pdist(embedding, metric="sqeuclidean"))
            )
            safe_squared = np.maximum(squared, 1e-6)
            membership = 1.0 / (1.0 + a_value * safe_squared**b_value)
            np.fill_diagonal(membership, 0.0)
            coefficients = 2 * b_value * (graph - membership) / safe_squared
            np.fill_diagonal(coefficients, 0.0)
            gradient = (np.diag(coefficients.sum(axis=1)) - coefficients) @ embedding
            norm = np.linalg.norm(gradient, axis=1, keepdims=True)
            gradient /= np.maximum(1.0, norm / 4.0)
            rate = self.config.learning_rate * (1.0 - epoch / self.config.n_epochs)
            embedding -= rate * gradient
            embedding -= embedding.mean(axis=0, keepdims=True)
            if epoch % 10 == 0 or epoch == self.config.n_epochs - 1:
                clipped = np.clip(membership[mask], 1e-8, 1 - 1e-8)
                weights = graph[mask]
                loss = -np.mean(
                    weights * np.log(clipped)
                    + (1.0 - weights) * np.log(1.0 - clipped)
                )
                self.history_.append(float(loss))
        if not np.isfinite(embedding).all():
            raise FloatingPointError("La optimizacion UMAP produjo valores invalidos.")
        self.graph_ = graph
        self._embedding = embedding
        return self.embedding_
