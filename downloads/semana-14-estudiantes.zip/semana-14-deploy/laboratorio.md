# Laboratorio · Despliegue reproducible con Streamlit

## Pregunta guía

¿Puede otro equipo tomar nuestros archivos, reconstruir el servicio y comprobar con evidencia que el modelo, la aplicación y la infraestructura se comportan como declaramos?

## Producto

Despliegue HTTPS de la aplicación de churn, construido con Docker Compose sobre una VM de Compute Engine. El repositorio entregado debe ser suficiente para reproducirlo sin secretos.

## Pruebas de aceptación

Complete la tabla con resultado y evidencia:

| ID | Prueba | Criterio |
|---|---|---|
| A1 | `docker compose config` | Termina sin error ni `TODO` |
| A2 | Construcción limpia | `docker compose build --no-cache app` termina |
| A3 | Salud | `app` aparece `healthy` |
| A4 | HTTPS | URL abre con certificado válido, sin `-k` |
| A5 | Redirección | HTTP redirige a HTTPS |
| A6 | Inferencia | El caso de referencia conserva clase y probabilidad dentro de ±0.001 |
| A7 | Explicación | La vista SHAP carga y se interpreta como asociación del modelo, no causalidad |
| A8 | Superficie | 8501 no es accesible públicamente |
| A9 | Reinicio | Tras recrear los servicios, la aplicación vuelve a estado saludable |
| A10 | Limpieza | No quedan VM, disco ni IP reservada al cerrar |

## Entregables

1. Archivos fuente: app, artefactos, dependencias, Dockerfile, Compose y Caddyfile.
2. Bitácora con comandos y decisiones; no incluya tokens, llaves ni identificadores sensibles.
3. Evidencia de proyecto, presupuesto y alertas.
4. Evidencia de cuenta de servicio adjunta, sin llaves.
5. URL y capturas de HTTPS, `compose ps`, logs pertinentes y pruebas A1–A10.
6. Evidencia de limpieza y reflexión de máximo 300 palabras.

## Rúbrica · 100 puntos

| Dimensión | Puntos | Excelente |
|---|---:|---|
| Reproducibilidad del modelo | 15 | Artefactos versionados, contrato explícito y paridad verificada |
| Dockerfile | 15 | Capas coherentes, versión fijada, usuario no root, salud y contexto mínimo |
| Compose y redes | 20 | App interna, dependencia por salud, Caddy, volúmenes y configuración válida |
| GCP, identidad y seguridad | 15 | Proyecto aislado, SA sin llave, IAP, solo 80/443 públicos |
| HTTPS y operación | 15 | Certificado válido, redirección, servicio saludable y logs interpretados |
| Costos y limpieza | 10 | Presupuesto/alertas, evidencia y eliminación completa |
| Explicación técnica | 10 | Distingue imagen, contenedor, composición, proxy e infraestructura |

## Penalizaciones críticas

- −20: publicar una llave de cuenta de servicio o un secreto.
- −10: dejar 8501 abierto a Internet.
- −10: dejar recursos cobrables sin acuerdo explícito del docente.
- La entrega puede recibir cero mientras contenga credenciales activas; deben revocarse antes de revisar.

## Trabajo individual breve

En máximo 150 palabras, responda: “Docker hace reproducible una parte del sistema. ¿Qué supuestos siguen dependiendo de la nube, la red y la operación humana?”.
