"""Implementacion exacta y pequena de t-SNE para fines educativos."""

from __future__ import annotations

from dataclasses import asdict
from typing import cast

import numpy as np
from scipy.spatial.distance import pdist, squareform

from manifold_lab.base import BaseEmbeddingReducer, FloatArray, validated_matrix
from manifold_lab.config import TSNEConfig


def _row_probabilities(distances: FloatArray, perplexity: float) -> FloatArray:
    """Busca una precision gaussiana por fila para lograr la perplejidad."""
    n_samples = distances.shape[0]
    target_entropy = np.log(perplexity)
    conditional = np.zeros_like(distances)
    for row in range(n_samples):
        mask = np.arange(n_samples) != row
        row_distances = distances[row, mask]
        lower, upper, beta = -np.inf, np.inf, 1.0
        probabilities = np.zeros_like(row_distances)
        for _ in range(60):
            weights = np.exp(-row_distances * beta)
            denominator = max(float(weights.sum()), np.finfo(float).tiny)
            probabilities = weights / denominator
            entropy = np.log(denominator) + beta * float(
                np.dot(row_distances, probabilities)
            )
            difference = entropy - target_entropy
            if abs(difference) < 1e-7:
                break
            if difference > 0:
                lower = beta
                beta = beta * 2 if np.isinf(upper) else (beta + upper) / 2
            else:
                upper = beta
                beta = beta / 2 if np.isinf(lower) else (beta + lower) / 2
        conditional[row, mask] = probabilities
    return conditional


def joint_probabilities(values: FloatArray, perplexity: float) -> FloatArray:
    """Construye afinidades simetricas de alta dimension que suman uno."""
    matrix = validated_matrix(values)
    distances = cast(FloatArray, squareform(pdist(matrix, metric="sqeuclidean")))
    conditional = _row_probabilities(distances, perplexity)
    joint = conditional + conditional.T
    joint /= joint.sum()
    return np.maximum(joint, np.finfo(float).tiny)


class TSNEFromScratch(BaseEmbeddingReducer):
    """t-SNE exacto O(n^2), apropiado solo para ejemplos pequenos."""

    def __init__(self, config: TSNEConfig | None = None) -> None:
        super().__init__()
        self.config = config or TSNEConfig()
        self.history_: list[float] = []

    @property
    def name(self) -> str:
        """Nombre del reductor."""
        return "t-SNE desde cero"

    def get_params(self) -> dict[str, object]:
        """Devuelve una copia de la configuracion."""
        return asdict(self.config)

    def fit_transform(self, values: FloatArray) -> FloatArray:
        """Optimiza KL mediante descenso con momento y exageracion temprana."""
        matrix = validated_matrix(values)
        n_samples = matrix.shape[0]
        self.config.validate(n_samples)
        if n_samples > 400:
            raise ValueError("La version exacta admite como maximo 400 filas.")
        probabilities = joint_probabilities(matrix, self.config.perplexity)
        random = np.random.default_rng(self.config.random_state)
        embedding = random.normal(0, 1e-4, size=(n_samples, 2))
        velocity = np.zeros_like(embedding)
        self.history_ = []
        for iteration in range(self.config.n_iter):
            distances = cast(
                FloatArray, squareform(pdist(embedding, metric="sqeuclidean"))
            )
            numerator = 1.0 / (1.0 + distances)
            np.fill_diagonal(numerator, 0.0)
            low_probabilities = numerator / numerator.sum()
            exaggeration = (
                self.config.early_exaggeration
                if iteration < self.config.exaggeration_iter
                else 1.0
            )
            weights = (exaggeration * probabilities - low_probabilities) * numerator
            gradient = 4.0 * (
                np.diag(weights.sum(axis=1)) - weights
            ) @ embedding
            momentum = 0.5 if iteration < 100 else 0.8
            velocity = momentum * velocity - self.config.learning_rate * gradient
            embedding += velocity
            embedding -= embedding.mean(axis=0, keepdims=True)
            if iteration % 10 == 0 or iteration == self.config.n_iter - 1:
                ratio = probabilities / np.maximum(
                    low_probabilities, np.finfo(float).tiny
                )
                self.history_.append(float(np.sum(probabilities * np.log(ratio))))
        if not np.isfinite(embedding).all():
            raise FloatingPointError("La optimizacion t-SNE produjo valores invalidos.")
        self._embedding = embedding
        return self.embedding_
