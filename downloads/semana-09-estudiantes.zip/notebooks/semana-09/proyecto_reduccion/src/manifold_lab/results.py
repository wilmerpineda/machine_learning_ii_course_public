"""Objetos inmutables para comunicar resultados y metricas."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TypeAlias

import numpy as np
from numpy.typing import NDArray

FloatArray: TypeAlias = NDArray[np.float64]


@dataclass(frozen=True, slots=True)
class EmbeddingResult:
    """Salida trazable de un ajuste de reduccion dimensional."""

    name: str
    coordinates: FloatArray
    parameters: dict[str, object]
    duration_seconds: float
    history: tuple[float, ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        """Protege el contrato bidimensional y finito."""
        if self.coordinates.ndim != 2 or self.coordinates.shape[1] != 2:
            raise ValueError("coordinates debe tener forma (n_samples, 2).")
        if not np.isfinite(self.coordinates).all():
            raise ValueError("coordinates contiene valores no finitos.")
        if self.duration_seconds < 0:
            raise ValueError("duration_seconds no puede ser negativo.")


@dataclass(frozen=True, slots=True)
class EmbeddingMetrics:
    """Diagnosticos locales, globales y computacionales de un embedding."""

    trustworthiness: float
    neighbor_overlap: float
    distance_correlation: float
    duration_seconds: float

    def as_dict(self) -> dict[str, float]:
        """Convierte las metricas en una fila tabular."""
        return {
            "trustworthiness": self.trustworthiness,
            "neighbor_overlap": self.neighbor_overlap,
            "distance_correlation": self.distance_correlation,
            "duration_seconds": self.duration_seconds,
        }
