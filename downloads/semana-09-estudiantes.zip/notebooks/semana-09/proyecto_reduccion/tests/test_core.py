"""Pruebas del contrato y de las implementaciones didacticas."""

from __future__ import annotations

import numpy as np
import pytest
from sklearn.datasets import make_s_curve

from manifold_lab import TSNEConfig, TSNEFromScratch, UMAPConfig, UMAPFromScratch
from manifold_lab.tsne import joint_probabilities
from manifold_lab.umap_model import fuzzy_neighbor_graph


@pytest.fixture(name="sample")
def fixture_sample() -> np.ndarray:
    """Crea una muestra no lineal pequena y reproducible."""
    values, _ = make_s_curve(n_samples=50, noise=0.02, random_state=42)
    return np.asarray(values, dtype=np.float64)


def test_tsne_probabilities_are_symmetric(sample: np.ndarray) -> None:
    """Las afinidades conjuntas deben ser probabilidades simetricas."""
    probabilities = joint_probabilities(sample, perplexity=8)
    assert np.allclose(probabilities, probabilities.T)
    assert np.isclose(probabilities.sum(), 1.0)
    assert np.all(probabilities > 0)


def test_fuzzy_graph_is_valid(sample: np.ndarray) -> None:
    """La union difusa debe ser simetrica y permanecer en [0, 1]."""
    graph = fuzzy_neighbor_graph(sample, n_neighbors=8)
    assert np.allclose(graph, graph.T)
    assert np.all((0 <= graph) & (graph <= 1))
    assert np.allclose(np.diag(graph), 0)


def test_reducers_return_two_dimensions(sample: np.ndarray) -> None:
    """Ambas implementaciones cumplen el contrato comun."""
    reducers = [
        TSNEFromScratch(TSNEConfig(perplexity=8, n_iter=60)),
        UMAPFromScratch(UMAPConfig(n_neighbors=8, n_epochs=60)),
    ]
    for reducer in reducers:
        coordinates = reducer.fit_transform(sample)
        assert coordinates.shape == (50, 2)
        assert np.isfinite(coordinates).all()
        assert np.allclose(coordinates, reducer.embedding_)


def test_embedding_before_fit_fails() -> None:
    """El estado no ajustado produce un error explicito."""
    with pytest.raises(RuntimeError):
        _ = TSNEFromScratch().embedding_


@pytest.mark.parametrize(
    "bad_value",
    [np.ones(4), np.ones((2, 2)), np.array([[1.0, np.nan], [2, 3], [4, 5]])],
)
def test_invalid_matrices_fail(bad_value: np.ndarray) -> None:
    """Las entradas que rompen el contrato se rechazan temprano."""
    with pytest.raises(ValueError):
        TSNEFromScratch().fit_transform(bad_value)
