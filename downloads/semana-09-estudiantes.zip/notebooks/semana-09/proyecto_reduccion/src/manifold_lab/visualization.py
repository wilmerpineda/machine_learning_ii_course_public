"""Visualizacion separada de ajuste y evaluacion."""

from __future__ import annotations

from typing import Any

import numpy as np

from manifold_lab.results import EmbeddingResult


class EmbeddingPlotter:
    """Dibuja embeddings sobre ejes creados por el llamador."""

    def scatter(
        self,
        axis: Any,
        result: EmbeddingResult,
        labels: np.ndarray[Any, Any],
        title: str | None = None,
    ) -> Any:
        """Agrega un diagrama de dispersion y devuelve el artista."""
        if len(labels) != len(result.coordinates):
            raise ValueError("labels y coordinates deben tener igual longitud.")
        artist = axis.scatter(
            result.coordinates[:, 0],
            result.coordinates[:, 1],
            c=labels,
            cmap="tab10",
            s=10,
            alpha=0.7,
        )
        axis.set_title(title or result.name)
        axis.set_xticks([])
        axis.set_yticks([])
        return artist
