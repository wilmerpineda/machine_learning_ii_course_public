"""Configuraciones validadas para los algoritmos didacticos."""

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class TSNEConfig:
    """Hiperparametros de la implementacion exacta de t-SNE."""

    perplexity: float = 20.0
    learning_rate: float = 100.0
    n_iter: int = 400
    early_exaggeration: float = 4.0
    exaggeration_iter: int = 100
    random_state: int = 42

    def validate(self, n_samples: int) -> None:
        """Valida rangos que dependen del numero de observaciones."""
        if not 1.0 < self.perplexity < n_samples:
            raise ValueError("perplexity debe estar entre 1 y n_samples.")
        if self.learning_rate <= 0 or self.n_iter < 50:
            raise ValueError("learning_rate debe ser positivo y n_iter >= 50.")
        if self.early_exaggeration < 1 or self.exaggeration_iter < 0:
            raise ValueError("La exageracion temprana tiene parametros invalidos.")


@dataclass(frozen=True, slots=True)
class UMAPConfig:
    """Hiperparametros de la implementacion densa y didactica de UMAP."""

    n_neighbors: int = 10
    min_dist: float = 0.1
    spread: float = 1.0
    learning_rate: float = 0.25
    n_epochs: int = 300
    random_state: int = 42

    def validate(self, n_samples: int) -> None:
        """Valida vecindad, geometria y optimizacion."""
        if not 2 <= self.n_neighbors < n_samples:
            raise ValueError("n_neighbors debe estar entre 2 y n_samples - 1.")
        if not 0 <= self.min_dist <= self.spread:
            raise ValueError("min_dist debe pertenecer a [0, spread].")
        if self.learning_rate <= 0 or self.n_epochs < 50:
            raise ValueError("learning_rate debe ser positivo y n_epochs >= 50.")
