"""Streamlit interface for the week 14 deployment lab."""

from __future__ import annotations

from pathlib import Path

import pandas as pd
import streamlit as st

from model_service import load_bundle, local_shap_values, predict


ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"


@st.cache_resource
def get_bundle():
    """Load deployment artifacts once per Streamlit process."""
    return load_bundle(ARTIFACT_DIR)


def input_widget(feature: str, contract: dict[str, object], key: str) -> float:
    """Render one bounded input from the serialized contract."""
    minimum = float(contract["minimum"])
    maximum = float(contract["maximum"])
    default = float(contract["default"])
    if bool(contract["integer"]):
        return float(
            st.number_input(
                feature,
                min_value=int(minimum),
                max_value=int(maximum),
                value=int(default),
                step=1,
                key=key,
            )
        )
    return float(
        st.number_input(
            feature,
            min_value=minimum,
            max_value=maximum,
            value=default,
            step=max((maximum - minimum) / 100, 0.01),
            key=key,
        )
    )


st.set_page_config(page_title="Churn explicable · ML II", page_icon="📡", layout="wide")
model, metadata = get_bundle()

st.title("Churn explicable")
st.caption(
    f"{metadata['model_name']} · versión {metadata['model_version']} · "
    "demostración académica"
)

with st.sidebar:
    st.header("Trazabilidad")
    st.write(f"Dataset: {metadata['dataset']}")
    st.write(f"Umbral validado: {metadata['decision_threshold']:.2f}")
    for name, value in metadata["metrics"].items():
        st.metric(name.replace("_", " ").title(), f"{value:.3f}")

st.subheader("1. Perfil de uso")
values: dict[str, float] = {}
columns = st.columns(3)
for index, feature in enumerate(metadata["feature_order"]):
    with columns[index % 3]:
        values[feature] = input_widget(
            feature,
            metadata["input_contract"][feature],
            key=f"input-{index}",
        )

if st.button("Estimar riesgo", type="primary", use_container_width=True):
    result = predict(model, metadata, values)
    left, right = st.columns(2)
    with left:
        st.metric("Probabilidad estimada de churn", f"{result['probability']:.1%}")
    with right:
        label = "Priorizar revisión" if result["prediction"] else "Sin alerta"
        st.metric("Decisión con el umbral validado", label)

    st.subheader("2. Explicación local")
    try:
        local = local_shap_values(model, metadata, values).head(8)
        st.bar_chart(local.set_index("variable")["aporte_shap"], horizontal=True)
        st.caption(
            "Valores positivos empujan la predicción hacia churn; valores negativos "
            "la alejan. La explicación describe el modelo, no una relación causal."
        )
    except Exception as error:  # visible diagnosis is preferable in a teaching app
        st.warning(f"No fue posible calcular SHAP: {error}")

st.subheader("3. Importancia global")
global_importance = pd.DataFrame(metadata["global_importance"]).head(10)
st.bar_chart(global_importance.set_index("feature")["importance"], horizontal=True)

with st.expander("Limitaciones y uso responsable"):
    for limitation in metadata["limitations"]:
        st.write(f"- {limitation}")
