"""Orquestacion de experimentos sin logica algoritmica en notebooks."""

from __future__ import annotations

from collections.abc import Iterable
from time import perf_counter

import pandas as pd

from manifold_lab.base import BaseEmbeddingReducer, FloatArray, validated_matrix
from manifold_lab.evaluation import EmbeddingEvaluator
from manifold_lab.results import EmbeddingResult


class ExperimentRunner:
    """Ejecuta reductores intercambiables y conserva resultados trazables."""

    def __init__(self, evaluator: EmbeddingEvaluator | None = None) -> None:
        self.evaluator = evaluator or EmbeddingEvaluator()

    def run(
        self, values: FloatArray, reducers: Iterable[BaseEmbeddingReducer]
    ) -> tuple[list[EmbeddingResult], pd.DataFrame]:
        """Ajusta reductores y devuelve resultados junto con sus metricas."""
        matrix = validated_matrix(values)
        results: list[EmbeddingResult] = []
        rows: list[dict[str, object]] = []
        for reducer in reducers:
            started = perf_counter()
            coordinates = reducer.fit_transform(matrix)
            duration = perf_counter() - started
            history = tuple(float(value) for value in getattr(reducer, "history_", ()))
            result = EmbeddingResult(
                reducer.name,
                coordinates,
                dict(reducer.get_params()),
                duration,
                history,
            )
            metrics = self.evaluator.evaluate(matrix, result)
            results.append(result)
            rows.append({"method": result.name, **metrics.as_dict()})
        return results, pd.DataFrame(rows)
