"""Pruebas de carga, adaptadores, orquestacion y visualizacion."""

from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pytest
import manifold_lab.adapters as adapter_module

from manifold_lab import (
    EmbeddingEvaluator,
    EmbeddingResult,
    ExperimentRunner,
    HARDatasetLoader,
    SklearnTSNEAdapter,
    TSNEConfig,
    UMAPConfig,
    UmapLearnAdapter,
)
from manifold_lab.base import BaseEmbeddingReducer, FloatArray
from manifold_lab.visualization import EmbeddingPlotter


class IdentityReducer(BaseEmbeddingReducer):
    """Reductor mínimo para probar el servicio de experimentos."""

    @property
    def name(self) -> str:
        """Devuelve el nombre de prueba."""
        return "identidad"

    def get_params(self) -> dict[str, object]:
        """No tiene hiperparámetros."""
        return {}

    def fit_transform(self, values: FloatArray) -> FloatArray:
        """Conserva las primeras dos columnas."""
        self._embedding = values[:, :2].copy()
        return self.embedding_


def test_dataset_loader_reads_offline_contract(tmp_path: Path) -> None:
    """El cargador alinea matriz, metadatos y nombres."""
    matrix = np.arange(24, dtype=float).reshape(6, 4)
    np.savez_compressed(tmp_path / "har_features.npz", X=matrix)
    pd.DataFrame(
        {
            "sample_id": range(6),
            "subject": [1] * 6,
            "activity": ["walk"] * 6,
            "split": ["train"] * 6,
        }
    ).to_csv(tmp_path / "har_metadata.csv", index=False)
    (tmp_path / "feature_names.txt").write_text("a\nb\nc\nd\n", encoding="utf-8")
    dataset = HARDatasetLoader(tmp_path).load()
    assert dataset.features.shape == (6, 4)
    assert dataset.feature_names == ("a", "b", "c", "d")


def test_dataset_loader_reports_missing_files(tmp_path: Path) -> None:
    """La ausencia de datos se informa antes del ajuste."""
    with pytest.raises(FileNotFoundError):
        HARDatasetLoader(tmp_path).load()


def test_experiment_runner_and_plotter() -> None:
    """Los servicios consumen la abstracción y el objeto resultado."""
    random = np.random.default_rng(42)
    values = random.normal(size=(60, 5))
    runner = ExperimentRunner(EmbeddingEvaluator(n_neighbors=5))
    results, table = runner.run(values, [IdentityReducer()])
    assert table.loc[0, "method"] == "identidad"
    figure, axis = plt.subplots()
    artist = EmbeddingPlotter().scatter(axis, results[0], np.arange(60) % 3)
    assert artist.get_offsets().shape == (60, 2)
    plt.close(figure)


def test_plotter_rejects_misaligned_labels() -> None:
    """La visualización valida la longitud de etiquetas."""
    result = EmbeddingResult("x", np.ones((5, 2)), {}, 0.0)
    figure, axis = plt.subplots()
    with pytest.raises(ValueError):
        EmbeddingPlotter().scatter(axis, result, np.ones(4))
    plt.close(figure)


def test_sklearn_adapter_runs(monkeypatch: pytest.MonkeyPatch) -> None:
    """El adaptador de scikit-learn respeta el contrato común."""

    class FakeTsne:
        """Sustituto rápido de la dependencia externa."""

        def __init__(self, **_: object) -> None:
            pass

        def fit_transform(self, values: FloatArray) -> FloatArray:
            """Conserva dos columnas para probar el adaptador."""
            return values[:, :2]

    monkeypatch.setattr(adapter_module, "TSNE", FakeTsne)
    values = np.random.default_rng(42).normal(size=(45, 6))
    adapter = SklearnTSNEAdapter(
        TSNEConfig(perplexity=8, n_iter=250, learning_rate=50)
    )
    assert adapter.fit_transform(values).shape == (45, 2)
    assert adapter.name == "t-SNE"


def test_umap_adapter_can_be_isolated(monkeypatch: pytest.MonkeyPatch) -> None:
    """El adaptador delega en UMAP sin acoplar al consumidor."""

    class FakeUmap:
        """Sustituto rápido de la dependencia externa."""

        def __init__(self, **_: object) -> None:
            pass

        def fit_transform(self, values: FloatArray) -> FloatArray:
            return values[:, :2]

    monkeypatch.setitem(sys.modules, "umap", SimpleNamespace(UMAP=FakeUmap))
    values = np.random.default_rng(42).normal(size=(30, 4))
    adapter = UmapLearnAdapter(UMAPConfig(n_neighbors=5, n_epochs=50))
    assert adapter.fit_transform(values).shape == (30, 2)
    assert adapter.name == "UMAP"


def test_config_validation_branches() -> None:
    """Las configuraciones rechazan rangos incompatibles."""
    with pytest.raises(ValueError):
        TSNEConfig(perplexity=50).validate(20)
    with pytest.raises(ValueError):
        TSNEConfig(learning_rate=0).validate(60)
    with pytest.raises(ValueError):
        UMAPConfig(n_neighbors=40).validate(20)
    with pytest.raises(ValueError):
        UMAPConfig(min_dist=2).validate(60)
    with pytest.raises(ValueError):
        UMAPConfig(learning_rate=0).validate(60)
