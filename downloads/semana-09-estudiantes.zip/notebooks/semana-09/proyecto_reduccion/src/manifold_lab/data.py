"""Carga y validacion del subconjunto de actividad humana."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
from numpy.typing import NDArray


@dataclass(frozen=True, slots=True)
class HARDataset:
    """Matriz de caracteristicas y metadatos alineados."""

    features: NDArray[np.float64]
    metadata: pd.DataFrame
    feature_names: tuple[str, ...]

    def __post_init__(self) -> None:
        """Comprueba dimensiones, finitud y columnas obligatorias."""
        required = {"sample_id", "subject", "activity", "split"}
        if self.features.ndim != 2 or not np.isfinite(self.features).all():
            raise ValueError("La matriz HAR debe ser bidimensional y finita.")
        if len(self.metadata) != self.features.shape[0]:
            raise ValueError("Caracteristicas y metadatos no estan alineados.")
        if len(self.feature_names) != self.features.shape[1]:
            raise ValueError("Los nombres no coinciden con las columnas.")
        if not required.issubset(self.metadata.columns):
            raise ValueError("Faltan columnas obligatorias en metadata.")


class HARDatasetLoader:
    """Carga el paquete offline sin realizar descargas implicitas."""

    def __init__(self, data_dir: Path) -> None:
        self._data_dir = Path(data_dir)

    def load(self) -> HARDataset:
        """Carga NPZ, CSV y nombres de variables desde ``data_dir``."""
        matrix_path = self._data_dir / "har_features.npz"
        metadata_path = self._data_dir / "har_metadata.csv"
        names_path = self._data_dir / "feature_names.txt"
        missing = [
            path.name
            for path in (matrix_path, metadata_path, names_path)
            if not path.exists()
        ]
        if missing:
            raise FileNotFoundError(f"Faltan archivos HAR: {', '.join(missing)}")
        with np.load(matrix_path) as archive:
            features = np.asarray(archive["X"], dtype=np.float64)
        metadata = pd.read_csv(metadata_path)
        names = tuple(names_path.read_text(encoding="utf-8").splitlines())
        return HARDataset(features, metadata, names)
